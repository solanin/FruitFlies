//
//  Constants.swift
//  FruitFlies
//
//  Created by igmstudent on 3/15/16.
//  Copyright © 2016 igmstudent. All rights reserved.
//

import Foundation
import SpriteKit

struct Constants{
    struct Font {
        static let MainFont = "Optima-ExtraBlack"
    }
    
    struct HUD{
        static let FontSize = CGFloat(50.0)
        static let FontColorWhite = SKColor(red: 0.90, green: 0.90, blue: 0.90, alpha: 1.0)
        static let Margin = CGFloat(10.0)
    }
    
    struct Image{
        static let Player = "player"
        static let Target = "target"
        static let Monster = "monster"
        static let Projectile = "projectile"
    }
    
    struct Scene {
        static let BackgroundColor = SKColor(red: 0.878, green: 0.69, blue: 1.0, alpha: 1.0)
    }
}